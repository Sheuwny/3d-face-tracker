import torch
import torch.nn as nn

class GroundingHead3D(nn.Module):
    def __init__(self, hidden_dim=768):
        super().__init__()
        
        # MLPs for continuous probability coordinate regression (X, Y, Z, W, L, H, theta, phi, psi)[cite: 1]
        self.box_regensor = nn.Sequential(
            nn.Linear(hidden_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 9) # 9 parameters: Centroid (3), Dimensions (3), Orientation Angles (3)[cite: 1]
        )
        
        # Sub-component vertex probability evaluator for binary grounding masks[cite: 1]
        self.mask_evaluator = nn.Sequential(
            nn.Linear(hidden_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 1),
            nn.Sigmoid() # Outputs continuous probability score y_i in [0, 1][cite: 1]
        )

    def forward(self, joint_manifold_M_s):
        """
        joint_manifold_M_s: Shared joint spatial-semantic latent space from Fusion Transformer[cite: 1]
        """
        # Step 1: Global aggregation over latent spatial features
        global_feature = torch.mean(joint_manifold_M_s, dim=1)
        
        # Step 2: Predict continuous 3D Bounding Box Parameters[cite: 1]
        bbox_3d = self.box_regensor(global_feature) # [Batch, 9] -> (X, Y, Z, w, l, h, theta, phi, psi)[cite: 1]
        
        # Step 3: Compute vertex-level target affordance probabilities y_hat_i in [0, 1][cite: 1]
        # Segregates target primitive (Red points in Fig. 4c) from background geometry (Grey points)[cite: 1]
        point_masks = self.mask_evaluator(joint_manifold_M_s) # [Batch, K, 1][cite: 1]
        
        return bbox_3d, point_masks