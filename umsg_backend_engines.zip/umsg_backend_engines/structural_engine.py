class StructuralEngine(nn.Module):
    def __init__(self, input_dim=3, hidden_dim=768, k_neighbors=16):
        super().__init__()
        self.k = k_neighbors
        
        # W_g projects structural positional matrices (7-dimensional delta vectors) 
        # into an intermediate spatial dimension D_g[cite: 1].
        self.W_g = nn.Linear(7, 256) 
        
        # W_p maps the localized patch representation into the shared 
        # structural feature matrix dimension D[cite: 1].
        self.W_p = nn.Linear(256, hidden_dim)
        
        # Layer Normalization ensures gradient stability across structural nodes[cite: 1].
        self.layer_norm = nn.LayerNorm(hidden_dim)

    def get_local_neighborhood(self, p_c, P):
        # Calculates the k-nearest neighbors (k-NN) to isolate local coordinate 
        # manifolds N(p_c) around sampled centroid vertices[cite: 1].
        distances = torch.cdist(p_c, P)
        _, knn_indices = torch.topk(distances, self.k, largest=False)
        return knn_indices

    def forward(self, P, p_c):
        """
        P: Raw 3D point cloud vertex distribution (N, 3)[cite: 1].
        p_c: Sampled centroid vertices (K, 3) representing structural patches[cite: 1].
        """
        # Step 1: Isolate local neighborhood geometry.
        knn_idx = self.get_local_neighborhood(p_c, P)
        p_i = P[:, knn_idx, :] # Shape: [Batch, K, k_neighbors, 3]
        
        # Step 2: Formulate the relative spatial delta vector function.
        # As defined in UMSG, this captures continuous structural topology variations:
        # delta(p_i, p_c) = [p_i || p_i - p_c || ||p_i - p_c||_2][cite: 1].
        p_diff = p_i - p_c.unsqueeze(2) # Relative position (p_i - p_c)
        p_dist = torch.norm(p_diff, dim=-1, keepdim=True) # Euclidean distance
        
        # Concatenate absolute position, relative offset, and distance into a 7D vector.
        delta_p = torch.cat([p_i, p_diff, p_dist], dim=-1) # Shape: [Batch, K, k, 7]
        
        # Step 3: Compute the localized patch descriptor f_patch(p_c).
        # We apply the W_g mapping and a symmetric max-pooling aggregation operator 
        # over the spatial channels[cite: 1].
        local_features = torch.relu(self.W_g(delta_p))
        f_patch, _ = torch.max(local_features, dim=2) 
        
        # Step 4: Project localized patch representations into the unified structural 
        # feature matrix X_p using linear mapping W_p and LayerNorm[cite: 1].
        X_p = self.layer_norm(self.W_p(f_patch))
        
        return X_p # Output Shape: [Batch, K, D]