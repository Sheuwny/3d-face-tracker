import torch
import torch.nn as nn

class DepthTopologyEngine(nn.Module):
    def __init__(self, focal_x=525.0, focal_y=525.0, center_x=320.0, center_y=240.0):
        super().__init__()
        # Camera intrinsic parameters used for calibrated 2D-to-3D focal transformation
        self.fx = focal_x
        self.fy = focal_y
        self.cx = center_x
        self.cy = center_y

    def forward(self, depth_map):
        """
        depth_map: Continuous depth field (B, 1, H, W) as shown in Figure 4(b)
        Returns: Dense 3D Point Cloud Field P in R^(N x 3)
        """
        batch_size, _, height, width = depth_map.shape
        
        # Step 1: Generate pixel grid coordinates (u, v) over the spatial height and width
        grid_y, grid_x = torch.meshgrid(
            torch.arange(0, height, device=depth_map.device),
            torch.arange(0, width, device=depth_map.device),
            indexing='ij'
        )
        
        # Step 2: Unroll pixel grid into flattened coordinate arrays
        u = grid_x.unsqueeze(0).expand(batch_size, -1, -1) # Horizontal coordinates
        v = grid_y.unsqueeze(0).expand(batch_size, -1, -1) # Vertical coordinates
        z = depth_map.squeeze(1)                           # Z-field metric depth
        
        # Step 3: Back-project pixel coordinates (u, v, z) into continuous 3D space (X, Y, Z)
        x = (u - self.cx) * z / self.fx
        y = (v - self.cy) * z / self.fy
        
        # Step 4: Stack into continuous vertex manifold matrix P in R^(N x 3)[cite: 1]
        point_cloud = torch.stack([x, y, z], dim=-1).reshape(batch_size, -1, 3)
        
        return point_cloud # Output Shape: [Batch, N_points, 3]