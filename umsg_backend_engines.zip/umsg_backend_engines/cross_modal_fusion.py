import torch
import torch.nn as nn
import math

class CrossModalFusionTransformer(nn.Module):
    def __init__(self, hidden_dim=768, num_heads=12):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads

        # Equations (8): Linear projections for Query (Q), Key (K), and Value (V)[cite: 1]
        self.W_Q = nn.Linear(hidden_dim, hidden_dim) # Query from Structural Point Tokens X_p[cite: 1]
        self.W_K = nn.Linear(hidden_dim, hidden_dim) # Key from Semantic Text Tokens X_t[cite: 1]
        self.W_V = nn.Linear(hidden_dim, hidden_dim) # Value from Semantic Text Tokens X_t[cite: 1]

        # Output projection layer (Equation 10)[cite: 1]
        self.W_O = nn.Linear(hidden_dim, hidden_dim)
        self.layer_norm = nn.LayerNorm(hidden_dim)

    def forward(self, X_p, X_t):
        """
        X_p: Structural Feature Matrix from Structural Engine [Batch, K, D][cite: 1]
        X_t: Semantic Feature Matrix from Semantic Engine [Batch, M, D][cite: 1]
        """
        B, K, D = X_p.shape
        _, M, _ = X_t.shape

        # Step 1: Compute Query (Q) from spatial features, Key (K) & Value (V) from text features[cite: 1]
        Q = self.W_Q(X_p).view(B, K, self.num_heads, self.head_dim).transpose(1, 2)
        K_mat = self.W_K(X_t).view(B, M, self.num_heads, self.head_dim).transpose(1, 2)
        V_mat = self.W_V(X_t).view(B, M, self.num_heads, self.head_dim).transpose(1, 2)

        # Step 2: Compute Scaled Dot-Product Cross-Attention Matrix (Equation 9)[cite: 1]
        # Attn(Q, K, V) = softmax(Q * K^T / sqrt(D)) * V[cite: 1]
        scores = torch.matmul(Q, K_mat.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(scores, dim=-1)
        context = torch.matmul(attn_weights, V_mat)

        # Step 3: Multi-Head Aggregation (Equation 10)[cite: 1]
        context = context.transpose(1, 2).contiguous().view(B, K, D)
        H_l = self.W_O(context)

        # Step 4: Residual update step: X_p^(l+1) = X_p^(l) + H^(l)[cite: 1]
        M_s = self.layer_norm(X_p + H_l)

        return M_s # Joint spatial-semantic representation matrix[cite: 1]