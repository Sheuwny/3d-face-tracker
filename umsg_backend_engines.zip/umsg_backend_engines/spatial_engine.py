class SpatialEngine(nn.Module):
    def __init__(self, hidden_dim=768): 
        super().__init__()
        # We employ a CNN or Vision Transformer (ViT) backbone to process 
        # raw 2D optical matrices[cite: 1].
        self.visual_encoder = AutoModel.from_pretrained("vit-base-patch16-224")
        
        # Projecting the 2D spatial embeddings into the shared hidden dimension D (768) 
        # so they can be pushed into the Fusion Transformer later[cite: 1].
        self.projection = nn.Linear(self.visual_encoder.config.hidden_size, hidden_dim)

    def forward(self, rgb_images):
        # Step 1: Extract patch-level features from the 2D optical arrays[cite: 1].
        visual_features = self.visual_encoder(rgb_images).last_hidden_state
        
        # Step 2: Map these features into the continuous cross-modal latent space.
        X_v = self.projection(visual_features)
        
        return X_v # Output Shape: [Batch, Patches, D]